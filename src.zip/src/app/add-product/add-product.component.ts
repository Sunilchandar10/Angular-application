import { Component } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Productobj } from '../home/productmodel';
import { ProductService } from '../home/product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent {

 //  
  addproduct :Productobj= new Productobj();

 constructor(private _productService : ProductService, private _router : Router)
 {
 
 }

ngOnInit(): void {
   
}

// to add the product this method is used 

onSubmit(){
  // Service call to Add new Product
  this._productService.addNewProduct(this.addproduct);

  // Redirect to Product List
  this._router.navigate(['list'])
}



}
