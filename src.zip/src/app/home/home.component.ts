
import { Component,OnInit } from '@angular/core';
import { AppRoutingModule} from '../app-routing.module';
import { Router,ActivatedRoute } from '@angular/router';
import { FormControl,FormGroup } from '@angular/forms';

import { IProdObject } from './product';
import { ProductService } from './product.service';

import { Productobj } from './productmodel'; 

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent  implements OnInit{

 productList : Productobj[];
 prod_details : Productobj;
  


  constructor(private _productService : ProductService,  private _router : Router)
  {

  }

  


 ngOnInit() {
    this.productList = this._productService.getProductList();  
 }
 
DeleteItem(i : any) {  
      this._productService.deleteProduct(i);
}



  editproduct(i : any)
  {
    
    console.log("index is "+ i);
     this.prod_details= this._productService.getProductDetails_byArrayIndex(i);
    //console.log(y)

    //this._router.navigate(['edit_prod',this.prod_details.id]);
    this._router.navigate(['edit',this.prod_details.id]);
    console.log("Edit Clicked" +this.prod_details.id );
  }
}
