import { Injectable } from "@angular/core";
import { IProdObject } from "./product";
import { Productobj } from "./productmodel";

@Injectable()

export class ProductService
{

// product list is saved in array

    private listProducts : Productobj[] = [

        

        { id:1,productName: 'Apple iPhone 14 (128 GB) - Starlight', productPrice: 67999, description : "Brand:apple,Storage:128GB,Cellular Tecnology:5G, Operating system: IOS "},
        { id:2,productName: 'OnePlus Nord CE 2 Lite 5G ', productPrice: 18499 , description : "Brand: OnePlus, Storage:6GBRAM 128GBinternal , Cellular Tecnology:5G, Operating system: Oxygen OS  "},
        { id:3,productName: 'Samsung Galaxy S20 FE 5G', productPrice: 26990, description : "Brand: Samsung, Storage:6GBRAM 128GBinternal, Cellular Tecnology:5G, Operating system: Android 11.0 " },
        { id:4,productName: 'Oppo A78 5G ', productPrice: 18999, description : "Brand:Oppo, Storage:6GBRAM 128GBinternal, Cellular Tecnology:5G, Operating system:13.0  "}
           ];

    

           private testProd : Productobj;
           private product_id :number;           
        
       // to use the update product this method is used 

           updateProduct(prod_id : any){
 
            //        this.listProducts.find(e => e.id === prod_id)
                         
                    console.log("Product details "+ prod_id);
                    
                  
                }

                // to get the product detais this method is used

          getProductDetails_byArrayIndex(arr_index : number)
           {
               console.log("Arry Index is "+ arr_index);
                return  this.listProducts[arr_index];
           }

                      

    getProductList(): Productobj[]
    {
       return this.listProducts;
    
    }
   
    // to add a new product this metho is used
    addNewProduct(newProduct : Productobj)
    {
        
        const prod_listSize =   this.listProducts.length;
        newProduct.id = prod_listSize+1;
        this.listProducts.push(newProduct);
        
        console.log("No of element in the list " + this.listProducts.length);
        
    }
        
    // to delete a product this method is used
    deleteProduct(i : any)
    {
        console.log("Delete Product Method Called");
        this.listProducts.splice(i,1);
    
    }

    getProductDetails_byProdId(prod_id : number)
    {
        console.log("Prodcuct Id "+ prod_id);

        //this.testProd.id =   prod_id;             
        

        // Got error while using this code
        const findIndex = this.listProducts.findIndex(e => e.id == prod_id);
        
    
        console.log("find Index "+ findIndex);

        return this.listProducts[findIndex];
    
    }

    editProduct(testProd : Productobj){
 
        //    this.listProducts.find(e => e.id === prod_id)
        
        const findIndex = this.listProducts.findIndex(e => e.id === testProd.id);
        
        this.listProducts[findIndex]=testProd;
        
        console.log("updated list " + this.listProducts[findIndex].productName);
      
    }
   


}
