export class Productobj {
id : number;
productName : string;
    productPrice : number;
    description : string;
}