export interface IProdObject
{
    productName : string;
    productPrice : number;
    description : string;
}
    
