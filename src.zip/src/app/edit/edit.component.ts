import { Component,OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ProductService } from '../home/product.service';
import { Productobj } from '../home/productmodel';
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {


  id:number;
  Productname:string;
  Productdescription:string;
  Productprice:number

  editproduct:Productobj = new Productobj();

  constructor(private _productService : ProductService,private route: ActivatedRoute, private _router: Router)
  {

   }

   // to get the product details using the routing parameter and displaying in the edit screen  

   ngOnInit(): void {
    
    console.log("Hia");
    this.id = this.route.snapshot.params['id'];
    this.editproduct = this._productService.getProductDetails_byProdId(this.id);
    console.log("Inside ngOnit edit Component "+ this.editproduct.productName);
  }


// update the information and routing to the product list
  onSubmit()
  {
    this._productService.updateProduct(this.editproduct);
    this._router.navigate(['list']);
    //console.log("product id "+ this.editProduct.id);

   
    
  }

}


